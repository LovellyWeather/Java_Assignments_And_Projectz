/**
 * Created by Tanner on 12/1/2015.
 */
public class Node {
    Node left;

    Node right;

    int value;

    public Node(int value) {
        this.value = value;
    }

}